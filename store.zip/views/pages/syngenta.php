<?php
require PARTS_DIR . 'header.php';
?>
<div class="container">
    <div class="product d-flex justify-content-center align-items-center ">
        <img class="image-main1  " src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
        <section class="text-product w-50">
            <h4 class="">Соняшник Сурелі Сінгента</h4>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam quis tempus mauris, ac condimentum enim. Nulla rhoncus lorem ac tempor vestibulum. Morbi ac ornare diam. Interdum et malesuada fames ac ante ipsum primis in faucibus. Duis luctus semper placerat. Duis a hendrerit urna. Mauris mollis turpis eget hendrerit sodales. Fusce sed tortor in mi tincidunt vehicula vitae ac tortor. Morbi pharetra commodo lorem accumsan placerat. Phasellus faucibus nisl eros, eu vestibulum justo molestie rhoncus. Proin ac auctor libero. Praesent sit amet pulvinar augue. Suspendisse mattis maximus felis, at euismod velit pretium sed. Cras purus justo, dapibus eget mi non, aliquam pulvinar lacus. Pellentesque ut velit vel ipsum convallis lacinia et ac enim.
            </p>
            <p class="text-danger ">Для оформлення замовлення телефонуйте за номером у контактах нижче</p>
        </section>
    </div>
</div>
<?php
require PARTS_DIR . 'footer.php';

