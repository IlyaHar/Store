<?php
require PARTS_DIR . 'header.php';
require PARTS_DIR . 'home/banner.php';
require PARTS_DIR . 'home/products.php';
require PARTS_DIR . 'footer.php';

