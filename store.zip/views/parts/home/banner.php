
<div class="container slide ">
        <div class="MySlides fade1 ">
            <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/banner.jpeg" style="width: 100% ;" alt="banner"></a>
        </div>
        <div class="MySlides fade1 ">
            <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/banner2.jpeg" style="width: 100%;" alt="banner"></a>
        </div>
        <div class="MySlides fade1 ">
            <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/banner3.jpeg" style="width: 100%;" alt="banner"></a>
        </div>
        <div class="MySlides fade1 ">
        <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/banner4.jpeg" style="width: 100%;" alt="banner"></a>
        </div>
</div>
<br>
<div  class="container d-flex justify-content-center">
    <span class="dot" onclick="currentSlide(1)"></span>
    <span class="dot" onclick="currentSlide(2)" ></span>
    <span class="dot" onclick="currentSlide(3)"></span>
    <span class="dot" onclick="currentSlide(4)"></span>
</div>