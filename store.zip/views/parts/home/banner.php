
<div class="container slide ">
        <div class="MySlides fade1 ">
            <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/0f2fed21ca681fe89a713358dd8c2d60.jpg" style="width: 100% ;" alt="banner"></a>
        </div>
        <div class="MySlides fade1 ">
            <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/139c6fbd8ed3855cd053d9406c26a922.jpg" style="width: 100%;" alt="banner"></a>
        </div>
        <div class="MySlides fade1 ">
            <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/3601bd11339a7dac201c9ff31a6cd5c4.jpg" style="width: 100%;" alt="banner"></a>
        </div>
        <div class="MySlides fade1 ">
        <a class="image" href="#"><img class="image-banner" src="<?= IMAGES_URI ?>/c27c2c9b0e6cfe32132ca5ab84c2527d.jpg" style="width: 100%;" alt="banner"></a>
        </div>
</div>
<br>
<div  class="container d-flex justify-content-center">
    <span class="dot" onclick="currentSlide(1)"></span>
    <span class="dot" onclick="currentSlide(2)" ></span>
    <span class="dot" onclick="currentSlide(3)"></span>
    <span class="dot" onclick="currentSlide(4)"></span>
</div>