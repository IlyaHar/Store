
<div class="container-lg card-body">
    <div id="popular-product"  class="main-products">
        <h2  class="product-main text-secondary">Популярні товари</h2>
    </div>
    <div class="card-container d-flex justify-content-center" id="products-container">
        <div class="card">
            <a href="/syngenta" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="card-container d-flex justify-content-center " id="products-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <button id="loadMoreButton" class="btn btn-primary btn-next">Подивитися ще</button>

    <div class="products-next" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="products-next" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
</div>

<div class="container-lg card-body">
    <div class="main-products">
        <h2 id="action-product" class="product-main text-secondary">Акційні товари</h2>
    </div>
    <div class="card-container d-flex justify-content-center" id="products-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="card-container d-flex justify-content-center " id="products-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <button id="loadMoreButton2" class="btn btn-primary">Подивитися ще</button>

    <div class="products-next2" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="products-next2" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
</div>

<div class="container-lg card-body">
    <div class="main-products">
        <h2 id="new-product" class="product-main text-secondary">Нові товари</h2>
    </div>
    <div class="card-container d-flex justify-content-center" id="products-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="card-container d-flex justify-content-center " id="products-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <button id="loadMoreButton3" class="btn btn-primary">Подивитися ще</button>

    <div class="products-next3" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="products-next3" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
</div>
<div class="container-lg card-body">
    <div class="main-products">
        <h2 id="discount" class="product-main text-secondary">Уцінка</h2>
    </div>
    <div class="card-container d-flex justify-content-center" id="products-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="card-container d-flex justify-content-center " id="products-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <button id="loadMoreButton4" class="btn btn-primary">Подивитися ще</button>

    <div class="products-next4" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
    <div class="products-next4" id="products-next-container">
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="" class="text-dark text-decoration-none">
                <div class="card-content">
                    <img class="image-main" src="<?= IMAGES_URI ?>/syngenta.jpg" alt="">
                    <h6 class="text-center mt-3">Соняшник Сурелі Сінгента</h6>
                    <p class="text-center text-danger price-card">330.60 грн / л</p>
                </div>
            </a>
        </div>
    </div>
</div>