<?php

switch (getUrl()) {
    case '':
        require PAGE_DIR . '/home.php';
        break;
    case 'sunflowers':
    require PAGE_DIR . '/sunflowers.php';
        break;
    case 'corn':
        require PAGE_DIR . '/corn.php';
        break;
    case 'soya':
        require PAGE_DIR . '/soya.php';
        break;
    case 'fertilizers':
        require PAGE_DIR . '/fertilizers.php';
        break;
    case 'herbicides':
        require PAGE_DIR . '/herbicides.php';
        break;
    case 'syngenta':
        require PAGE_DIR . '/syngenta.php';
        break;
    case 'rekold':
        require PAGE_DIR . '/rekold.php';
        break;
    case 'aldazor':
        require PAGE_DIR . '/aldazor.php';
        break;
    case 'aldazorst':
        require PAGE_DIR . '/aldazorst.php';
        break;
    case 'impulse':
        require PAGE_DIR . '/impulse.php';
        break;
    case 'impulsest':
        require PAGE_DIR . '/impulsest.php';
        break;
    case 'volodimir':
        require PAGE_DIR . '/volodimir.php';
        break;
    case 'castelo':
        require PAGE_DIR . '/castelo.php';
        break;
    case 'bomond':
        require PAGE_DIR . '/bomond.php';
        break;
    case 'rivas':
        require PAGE_DIR . '/rivas.php';
        break;
    case 'banano':
        require PAGE_DIR . '/banano.php';
        break;
    case 'varum':
        require PAGE_DIR . '/varum.php';
        break;
    case 'hotin':
        require PAGE_DIR . '/hotin.php';
        break;
    case 'creative':
        require PAGE_DIR . '/creative.php';
        break;
    case 'soya1':
        require PAGE_DIR . '/soya1.php';
        break;
    case 'soya2':
        require PAGE_DIR . '/soya2.php';
        break;
    case 'ventura':
        require PAGE_DIR . '/ventura.php';
        break;
    case 'pristar':
        require PAGE_DIR . '/pristar.php';
        break;
    case 'pragmat':
        require PAGE_DIR . '/pragmat.php';
        break;
    case 'prospero':
        require PAGE_DIR . '/prospero.php';
        break;
    case 'spiner':
        require PAGE_DIR . '/spiner.php';
        break;
    case 'migel':
        require PAGE_DIR . '/migel.php';
        break;
    case 'youkatan':
        require PAGE_DIR . '/youkatan.php';
        break;
    case 'stiven':
        require PAGE_DIR . '/stiven.php';
        break;
    case 'material':
        require PAGE_DIR . '/material.php';
        break;





    default:
        throw new Exception(getUrl() . ' - not found', 404);
}

