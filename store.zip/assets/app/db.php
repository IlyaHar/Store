<?php

function dbSelect(string $table)
{

}
